package com.example.gauravassignmentthree;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class accelerometer extends AppCompatActivity implements SensorEventListener{
    private SensorManager sensorManager;
    private Sensor accelerometer;
    TextView x, y, z;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accelerometer);
        x =findViewById(R.id.x);
        y =findViewById(R.id.y);
        z =findViewById(R.id.z);
        sensorManager=(SensorManager)getSystemService(Context.SENSOR_SERVICE);
        accelerometer=sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        if(accelerometer!=null){
            sensorManager.registerListener(accelerometer.this,accelerometer,SensorManager.SENSOR_DELAY_NORMAL);
        }
        else{
            Toast.makeText(getApplicationContext(),"Accelerometer Not Supported",Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        Sensor sensor=sensorEvent.sensor;
        if(sensor.getType()==Sensor.TYPE_ACCELEROMETER){
            x.setText("X-axis : "+sensorEvent.values[0]);
            x.setAlpha(0.5f);
            y.setText("Y-axis : "+sensorEvent.values[1]);
            y.setAlpha(0.5f);
            z.setText("Z-axis : "+sensorEvent.values[2]);
            z.setAlpha(0.5f);
        }
        else{
            Toast.makeText(getApplicationContext(),"Sensor not Available",Toast.LENGTH_LONG).show();
        }
    }
    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }
}