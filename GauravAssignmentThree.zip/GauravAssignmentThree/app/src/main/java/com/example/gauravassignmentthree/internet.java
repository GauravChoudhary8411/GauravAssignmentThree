package com.example.gauravassignmentthree;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class internet extends AppCompatActivity {
    ConnectivityManager cm;
    EditText url;
    ProgressDialog pDialog;
    public static final int progress_bar_type = 0;
    String u = "";
    TextView tv;
    boolean flag = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_internet);
        cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        url = findViewById(R.id.url);
        tv = findViewById(R.id.tv);
    }

    @Deprecated
    @Override
    protected Dialog onCreateDialog(int id) {
        pDialog = new ProgressDialog(this);
        pDialog.setMessage("Downloading File. Please Wait...");
        pDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        pDialog.setCancelable(false);
        pDialog.show();
        return pDialog;
    }


    @Override
    protected void onStart() {
        super.onStart();
        checkWritePermission();
    }

    void checkWritePermission() {
        if ((ActivityCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED)) {
            flag = true;
            Toast.makeText(this, "permission Already granted ",
                    Toast.LENGTH_LONG).show();
        } else {
            ActivityCompat.requestPermissions(this, new String[]{
                    Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                checkWritePermission();
            } else {
                Toast.makeText(this, "Write permission denied by user ", Toast.LENGTH_LONG).show();
            }
        }
    }

    public void checkNetworkStatus(View v) {
        NetworkInfo info = cm.getActiveNetworkInfo();
        if (info != null) {
            if (info.getType() == ConnectivityManager.TYPE_WIFI) {
                u = url.getText().toString();
                new MyTextFile().execute(u);
                Toast.makeText(this, "Connected with WIFI", Toast.LENGTH_LONG).show();
            } else if (info.getType() == ConnectivityManager.TYPE_MOBILE) {
                u = url.getText().toString();
                new MyTextFile().execute(u);
                Toast.makeText(this, "Connected with Mobile", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "No network found", Toast.LENGTH_LONG).show();
            }

        }
    }

    class MyTextFile extends AsyncTask<String, String, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            showDialog(progress_bar_type);
        }

        @Override
        protected String doInBackground(String... strings) {
            return downloadText(strings[0]);
        }

        String downloadText(String path) {
            String s = null;
            try {
                URL myurl = new URL(path);
                HttpURLConnection httpURLConnection = (HttpURLConnection) myurl.openConnection();
                httpURLConnection.setRequestMethod("GET");
                httpURLConnection.setDoInput(true);
                httpURLConnection.connect();
                int code = httpURLConnection.getResponseCode();
                if (code == httpURLConnection.HTTP_OK) {
                    InputStream stream = httpURLConnection.getInputStream();
                    if (stream != null) {
                        BufferedReader reader = new BufferedReader((new InputStreamReader(stream)));
                        String line = "";
                        String text = "";
                        while ((line = reader.readLine()) != null) {
                            text = text + line + "\n";
                        }
                        s = text;
                        if (flag) {
                            String state = Environment.getExternalStorageState();
                            if (state.equals(Environment.MEDIA_MOUNTED)) {
                                File root = Environment.getExternalStorageDirectory();
                                File f = new File(root, "datatoread.txt");
                                FileOutputStream ff = new FileOutputStream(f);
                                byte[] b = s.getBytes();
                                ff.write(b);
                                ff.close();
                            }
                        }
                    }
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return s;
        }

        @Override
        protected void onProgressUpdate(String... progress) {
            Log.d("ANDRO_ASYNC", progress[0]);
            pDialog.setProgress(Integer.parseInt(progress[0]));
        }

        @Override
        protected void onPostExecute(String s) {
            dismissDialog(progress_bar_type);
            if (s != null) {
                tv.setText(s);
            }
        }
    }
}