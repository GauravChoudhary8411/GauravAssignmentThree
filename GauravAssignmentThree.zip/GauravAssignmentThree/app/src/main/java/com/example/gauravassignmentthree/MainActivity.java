package com.example.gauravassignmentthree;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button acc, proxi, internet;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        acc=findViewById(R.id.accelerate);
        proxi=findViewById(R.id.prox);
        internet=findViewById(R.id.net);

    }

    public void accelerometer(View view) {
        Intent i=new Intent(this, accelerometer.class);
        startActivity(i);
    }

    public void internet(View view) {
        Intent i=new Intent(this,internet.class);
        startActivity(i);
    }

    public void proximity(View view) {
        Intent i=new Intent(this,proximity.class);
        startActivity(i);
    }
}